import React, { useState, useEffect, useRef } from 'react';
import { Search, X, ArrowRight } from 'lucide-react';
import { ToolDefinition } from '../types/tools';
import { DynamicIcon } from './DynamicIcon';
import { searchTools } from '../data/toolsRegistry';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTool: (tool: ToolDefinition) => void;
  initialQuery?: string;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  onSelectTool,
  initialQuery = '',
}) => {
  const [query, setQuery] = useState(initialQuery);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const results = searchTools(query);

  useEffect(() => {
    if (isOpen) {
      setQuery(initialQuery);
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen, initialQuery]);

  useEffect(() => {
    setSelectedIndex(0);
  }, [query]);

  // Keyboard shortcut listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isOpen) return;

      if (e.key === 'Escape') {
        onClose();
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (results.length > 0 ? (prev + 1) % results.length : 0));
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (results.length > 0 ? (prev - 1 + results.length) % results.length : 0));
      } else if (e.key === 'Enter' && results[selectedIndex]) {
        e.preventDefault();
        onSelectTool(results[selectedIndex]);
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, results, selectedIndex, onClose, onSelectTool]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 sm:pt-24 px-4 bg-black/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div
        className="w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-[#EEEEEE] overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="relative flex items-center border-b border-[#EEEEEE] px-4 py-3.5 sm:py-4">
          <Search className="w-5 h-5 text-[#E53935] shrink-0 mr-3" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search any tool... (e.g. merge pdf, jpg to png, compress, qr)"
            className="w-full text-base sm:text-lg text-[#171717] placeholder:text-[#999999] focus:outline-none bg-transparent"
          />
          {query ? (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-neutral-400 hover:text-neutral-700 rounded-md"
              aria-label="Clear query"
            >
              <X className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="px-2 py-1 text-xs font-medium text-neutral-400 hover:text-neutral-700 bg-neutral-100 rounded-md"
            >
              ESC
            </button>
          )}
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-2 divide-y divide-[#F7F7F7]">
          {query.trim() === '' ? (
            <div className="p-8 text-center text-[#888888]">
              <p className="text-sm font-medium mb-3">Popular Searches</p>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {['Merge PDF', 'JPG to PNG', 'Compress PDF', 'Image Compressor', 'PDF to Word', 'QR Code'].map(
                  (term) => (
                    <button
                      key={term}
                      onClick={() => setQuery(term)}
                      className="text-xs px-3 py-1.5 rounded-lg bg-[#FFF7F7] text-[#E53935] hover:bg-[#FFE8E8] transition-colors font-medium border border-[#F5DCDC]"
                    >
                      {term}
                    </button>
                  )
                )}
              </div>
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-sm font-medium text-[#171717] mb-1">No tools matched "{query}"</p>
              <p className="text-xs text-[#888888]">Try searching by file format (e.g. PDF, JPG, DOCX, WebP) or action (e.g. merge, compress, resize).</p>
            </div>
          ) : (
            results.map((tool, idx) => {
              const isSelected = idx === selectedIndex;
              return (
                <div
                  key={tool.id}
                  onClick={() => {
                    onSelectTool(tool);
                    onClose();
                  }}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between p-3 rounded-xl cursor-pointer transition-all ${
                    isSelected ? 'bg-[#FFF0F0] text-[#E53935]' : 'hover:bg-[#FFF7F7] text-[#171717]'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        isSelected ? 'bg-[#E53935] text-white' : 'bg-[#FFF0F0] text-[#E53935]'
                      }`}
                    >
                      <DynamicIcon name={tool.iconName} className="w-5 h-5" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-bold text-[#171717] truncate">{tool.name}</span>
                        <span className="text-[11px] text-[#888888]">· {tool.categoryLabel}</span>
                      </div>
                      <p className="text-xs text-[#666666] truncate">{tool.shortDescription}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 text-xs font-semibold text-[#E53935] shrink-0 pl-2">
                    <span className="hidden sm:inline">Open</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer shortcuts info */}
        <div className="px-4 py-2.5 bg-[#FAF8F8] border-t border-[#EEEEEE] text-[11px] text-[#888888] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span>Use <kbd className="px-1 py-0.5 bg-white border border-[#DDD] rounded text-[10px]">↑</kbd> <kbd className="px-1 py-0.5 bg-white border border-[#DDD] rounded text-[10px]">↓</kbd> to navigate</span>
            <span><kbd className="px-1 py-0.5 bg-white border border-[#DDD] rounded text-[10px]">↵</kbd> to select</span>
          </div>
          <span>Client-side private</span>
        </div>
      </div>
    </div>
  );
};
