import React from 'react';
import { Wrench, ShieldCheck, Heart } from 'lucide-react';
import { ToolDefinition } from '../types/tools';

interface FooterProps {
  onSelectToolSlug: (slug: string) => void;
  onOpenFaq: () => void;
  onOpenPrivacy: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onSelectToolSlug,
  onOpenFaq,
  onOpenPrivacy,
}) => {
  return (
    <footer className="bg-white border-t border-[#EEEEEE] pt-14 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Brand info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#E53935] text-white flex items-center justify-center shadow-xs">
                <Wrench className="w-4 h-4" />
              </div>
              <span className="text-xl font-extrabold tracking-tight text-[#171717]">
                Tools <span className="text-[#E53935]">Workshop</span>
              </span>
            </div>
            <p className="text-xs sm:text-sm text-[#666666] max-w-sm leading-relaxed">
              Your all-in-one online file and productivity toolbox. Convert, compress, merge, and transform files quickly and privately.
            </p>
            <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-100 max-w-fit">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <span>Zero server retention · Client-side engine</span>
            </div>
          </div>

          {/* PDF Tools */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#171717] mb-3">
              PDF Tools
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#666666]">
              {[
                { label: 'Merge PDF', slug: 'merge-pdf' },
                { label: 'Split PDF', slug: 'split-pdf' },
                { label: 'Compress PDF', slug: 'compress-pdf' },
                { label: 'PDF to Word', slug: 'pdf-to-word' },
                { label: 'PDF to JPG', slug: 'pdf-to-jpg' },
              ].map((item) => (
                <li key={item.slug}>
                  <button
                    onClick={() => onSelectToolSlug(item.slug)}
                    className="hover:text-[#E53935] transition-colors"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Image Tools */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#171717] mb-3">
              Image Tools
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#666666]">
              {[
                { label: 'JPG to PNG', slug: 'jpg-to-png' },
                { label: 'PNG to JPG', slug: 'png-to-jpg' },
                { label: 'WebP to JPG', slug: 'webp-to-jpg' },
                { label: 'Image Compressor', slug: 'image-compressor' },
                { label: 'Resize Image', slug: 'resize-image' },
              ].map((item) => (
                <li key={item.slug}>
                  <button
                    onClick={() => onSelectToolSlug(item.slug)}
                    className="hover:text-[#E53935] transition-colors"
                  >
                    {item.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-[#171717] mb-3">
              Company
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-[#666666]">
              <li>
                <button onClick={onOpenPrivacy} className="hover:text-[#E53935] transition-colors">
                  About Tools Workshop
                </button>
              </li>
              <li>
                <button onClick={onOpenFaq} className="hover:text-[#E53935] transition-colors">
                  FAQ
                </button>
              </li>
              <li>
                <button onClick={onOpenPrivacy} className="hover:text-[#E53935] transition-colors">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={onOpenPrivacy} className="hover:text-[#E53935] transition-colors">
                  Terms of Service
                </button>
              </li>
              <li>
                <a
                  href="/tools-workshop.zip"
                  download="tools-workshop.zip"
                  className="inline-flex items-center gap-1 font-semibold text-red-500 hover:text-red-600 transition-colors"
                >
                  <span>Download Source (.ZIP)</span>
                </a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright & attribution */}
        <div className="pt-8 border-t border-[#EEEEEE] flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-[#888888]">
          <p>© 2026 Tools Workshop. All rights reserved.</p>
          <p className="flex items-center gap-1">
            Built with modern web standards and client-side privacy.
          </p>
        </div>
      </div>
    </footer>
  );
};
